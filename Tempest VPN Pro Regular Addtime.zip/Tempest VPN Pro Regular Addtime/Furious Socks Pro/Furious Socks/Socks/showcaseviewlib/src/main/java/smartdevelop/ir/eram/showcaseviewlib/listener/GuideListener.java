package smartdevelop.ir.eram.showcaseviewlib.listener;

import android.view.View;

public interface GuideListener {
    void onDismiss(View view);
}
